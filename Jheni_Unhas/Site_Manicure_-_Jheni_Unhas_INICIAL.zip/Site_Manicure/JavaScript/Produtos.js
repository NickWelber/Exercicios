var carrinho = new Array();
var formaPagamento;
var usuario = new Array();

function comprar(nome, valor){
    var produto = [nome, valor]

    carrinho.push(produto);
    alert("ADD = " +carrinho);
}


function logar(){
    this.usuario = new Array();
    this.usuario.push(document.getElementById('nome_login').value);  
    
    
    if(this.usuario!=""){
        alert("Olá " +this.usuario+ "!!! Tenha Uma Exelente Compra ;D");     
    }else{
        alert("Senha ou Usuário inválido."); 
    }    
}

function cadastrar(){
    this.usuario = new Array();
    this.usuario.push(document.getElementById('nome_cad').value);

    if(this.usuario!=""){
        alert("Seja Bem-Vindo! " +this.usuario+ "!!! Realize Diversas Compras!!! ;D");
        alert("Agora clique no botão ''IR PARA LOGIN'' e realize o login");            
    }else{
        alert("Senha ou Usuário inválido."); 
    }    
}



